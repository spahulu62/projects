"""
Test code for functions and classes for the Dessert Shop(dessert.py)
The current test for each of the classes are for the default values, provided values, updated values
What is written so far as of Sept 27, 2025 should be 100% of test cases pass and each value provided and
updated to should also be the expected outcome.

Funny note: Writing this test code actually showed me I forgot to insert the proper default name value for the IceCream
and Sundae classes

Update: New test if new abstract method calculated_cost is overwritten and working correctly
        New test for calculate_tax method is computing correctly
        Oct 5,2025
Update: Added test to check if correct value for packaging
        Oct 24 ,2025

Author: Spencer Pahulu
Date: October 24, 2025
"""
import pytest
from dessert import Candy

#
#Class to test Candy Class
#
class TestCandy:
    #test if all default values are correct
    def test_default_attributes(self):
        candy = Candy()
        assert candy.name == ''
        assert candy.candy_weight == 0.0
        assert candy.price_per_pound == 0.0

    #test if providing attributes will update and contain correct values
    def test_provided_attributes(self):
        candy = Candy(name = 'Gummy Bear', price_per_pound = 3.0, candy_weight = 1.0)
        assert candy.name == 'Gummy Bear'
        assert candy.candy_weight == 1.0
        assert candy.price_per_pound == 3.0

    #test if updating values from provided values will contain correct values
    def test_update_attributes(self):
        candy = Candy(name='Gummy Bear', price_per_pound=3.0, candy_weight=1.0)
        candy.name = 'Candy Corn'
        candy.price_per_pound = 1.5
        candy.candy_weight = 0.5
        assert candy.name == 'Candy Corn'
        assert candy.candy_weight == 0.5
        assert candy.price_per_pound == 1.5

    #test if calculate_cost method is computing correctly
    def test_calculate_cost(self):
        candy = Candy('Candy Corn', 1.5, .25)
        assert candy.calculate_cost() == .38

    #test if calculate_tax from super class is computing correctly
    def test_calculate_tax(self):
        candy = Candy('Candy Corn', 1.5, .25)
        assert candy.calculate_tax() == 0.03

    def test_packaging(self):
        instance = Candy('Candy Corn',1.5,0.25)
        assert instance.packaging == 'Bag'
