"""
Test Code to test Order Class in dessert.py

Check for default values and values for each PayType
Chack to see if invalid value raises error
Check if getting invalid value raises error

update: added test to check if sort method works correctly and sorts by price
        Noc 14, 2025

Author: Spencer Pahulu
Date: November 14, 2025
"""
import pytest

from payment import PayType
from dessert import Order, Candy, Cookie, IceCream, Sundae


class TestOrder:
    def test_get_pay_type(self):
        order = Order()
        order.pay_type = "invalid"  # Manually set an invalid value for the test
        with pytest.raises(ValueError):
            order.get_pay_type()

    # noinspection PyTypeChecker
    def test_set_pay_type(self):
        order = Order()
        with pytest.raises(ValueError):
            order.set_pay_type('invalid')

    def test_pay_type_default(self):
        order = Order()
        assert order.pay_type == PayType.CASH

    def test_pay_type_card(self):
        order = Order()
        order.pay_type = "Card"
        assert order.pay_type == PayType.CARD.value

    def test_pay_type_phone(self):
        order = Order()
        order.pay_type = "Phone"
        assert order.pay_type == PayType.PHONE.value

    def test_pay_type_cash(self):
        order = Order()
        order.pay_type = "Cash"
        assert order.pay_type == PayType.CASH.value

    def test_sort(self):
        order = Order()
        order.add(Candy("Gummy Bears", 0.25, 0.35))
        order.add(IceCream("Pistachio", 2, 0.79))
        order.add(Sundae("Vanilla", 3, 0.69, "Hot Fudge", 1.29))
        order.add(Cookie("Chocolate Chip", 6, 3.99))

        order.sort()

        assert order.order[0] == Candy("Gummy Bears", 0.25, 0.35)
        assert order.order[1] == IceCream("Pistachio", 2, 0.79)
        assert order.order[2] == Cookie("Chocolate Chip", 6, 3.99)
        assert order.order[3] == Sundae("Vanilla", 3, 0.69,"Hot Fudge",
                                        1.29)
