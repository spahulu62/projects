"""
Protocol Module for dessert shop

Author: Spencer Pahulu
Date: October 24, 2025
"""
from typing import Protocol

class Packaging(Protocol):
    packaging: str