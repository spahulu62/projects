"""
Test code for functions and classes for the Dessert Shop(dessert.py)
The current test for each of the classes are for the default values, provided values, updated values
What is written so far as of Sept 27, 2025 should be 100% of test cases pass and each value provided and
updated to should also be the expected outcome.

Funny note: Writing this test code actually showed me I forgot to insert the proper default name value for the IceCream
and Sundae classes

Update: New test if new abstract method calculated_cost is overwritten and working correctly
        New test for calculate_tax method is computing correctly
        Oct 5,2025

Update: Added test to check if correct value for packaging
        Oct 24 ,2025

Author: Spencer Pahulu
Date: October 24, 2025
"""
import pytest
from dessert import Cookie

#
#Class to test Cookie Class
#
class TestCookie:
    #test if default attributes are correct
    def test_default_attributes(self):
        cookie = Cookie()
        assert cookie.name == ''
        assert cookie.cookie_quantity == 0.0
        assert cookie.price_per_dozen == 0.0

    #test if provided values will update and contain correct values
    def test_provided_attributes(self):
        cookie = Cookie('Chocolate Chip', 1, 4.5)
        assert cookie.name == 'Chocolate Chip'
        assert cookie.cookie_quantity == 1.0
        assert cookie.price_per_dozen == 4.5

    #test if updating provided values will update and contain correct values
    def test_update_attributes(self):
        cookie = Cookie('Chocolate Chip', 1, 4.5)
        cookie.name = 'PeanutButter'
        cookie.price_per_dozen = 3.0
        cookie.cookie_quantity = 4.0
        assert cookie.name == 'PeanutButter'
        assert cookie.price_per_dozen == 3.0
        assert cookie.cookie_quantity == 4.0

    #test if calculate_cost method is computing correctly
    def test_calculate_cost(self):
        cookie = Cookie("Chocolate Chip", 6, 3.99)
        assert cookie.calculate_cost() == 2.00

    # test if calculate_tax from super class is computing correctly
    def test_calculate_tax(self):
        cookie = Cookie("Chocolate Chip", 6, 3.99)
        assert cookie.calculate_tax() == 0.14

    def test_packaging(self):
        cookie = Cookie("Chocolate Chip", 6, 3.99)
        assert cookie.packaging == 'Box'