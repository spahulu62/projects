"""
DessertShop Payment method. This module chooses a payment method with the default set as CASH. Protocol classes
will choose which payment method through a prompt and __str__ method to print the method type at the end of the
receipt

Author: Spencer Pahulu
Date: November
"""

from typing import Protocol
from enum import Enum

class PayType(Enum):
    CASH = 'Cash'
    CARD = 'Card'
    PHONE = 'Phone'


class Payable(Protocol):

    def get_pay_type(self):
        """gets the payment type"""

        ...

    def set_pay_type(self, payment_method: PayType) -> None:
        """sets the payment type"""


        ...