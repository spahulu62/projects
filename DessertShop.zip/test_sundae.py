"""
Test code for functions and classes for the Dessert Shop(dessert.py)
The current test for each of the classes are for the default values, provided values, updated values
What is written so far as of Sept 27, 2025 should be 100% of test cases pass and each value provided and
updated to should also be the expected outcome.

Funny note: Writing this test code actually showed me I forgot to insert the proper default name value for the IceCream
and Sundae classes

Update: New test if new abstract method calculated_cost is overwritten and working correctly
        New test for calculate_tax method is computing correctly
        Oct 5,2025

Update: Added test to check if correct value for packaging
        Oct 24 ,2025

Author: Spencer Pahulu
Date: October 24, 2025
"""
import pytest
from dessert import Sundae, IceCream


#
#Class to test Sundae Class
#
class TestSundae:
    #test if default values are correct
    def test_default_attributes(self):
        sundae = Sundae()
        assert sundae.name == ''
        assert sundae.scoop_count == 0
        assert sundae.price_per_scoop == 0.0
        assert sundae.topping_name == ''
        assert sundae.topping_price == 0.0

    #test if providing values will update and contain correct values
    def test_provided_attributes(self):
        sundae = Sundae('Vanilla', 3, .75,'Hot Fudge', 1.25)
        assert sundae.name == 'Vanilla'
        assert sundae.scoop_count == 3
        assert sundae.price_per_scoop == .75
        assert sundae.topping_name == 'Hot Fudge'
        assert sundae.topping_price == 1.25

    #test if updating provided values will update and contain correct values
    def test_update_attributes(self):
        sundae = Sundae('Vanilla', 3, .75, 'Hot Fudge', 1.25)
        sundae.name = 'Chocolate'
        sundae.topping_name = 'Sprinkles'
        sundae.topping_price = 2.25
        sundae.scoop_count = 3
        sundae.price_per_scoop = .50
        assert sundae.name == 'Chocolate'
        assert sundae.topping_name == 'Sprinkles'
        assert sundae.topping_price == 2.25
        assert sundae.scoop_count == 3
        assert sundae.price_per_scoop == .50

    # test if calculate_cost method is computing correctly
    def test_calculate_cost(self):
        sundae = Sundae("Vanilla", 3, .69,
                              "Hot Fudge", 1.29)
        assert sundae.calculate_cost() == 3.36

    # test if calculate_tax from super class is computing correctly
    def test_calculate_tax(self):
        sundae = Sundae("Vanilla", 3, .69,
                              "Hot Fudge", 1.29)
        assert sundae.calculate_tax() == 0.24

    def test_packaging(self):
        sundae =  Sundae("Vanilla", 3, .69,
                              "Hot Fudge", 1.29)
        assert sundae.packaging == 'Boat'