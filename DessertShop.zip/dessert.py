"""
Dessert Shop: Create a program for a dessert shop that sells dessert items.
A Dessert Shop sells candy by the pound, cookies by the dozen, ice cream by
the scoop, and sundaes (ice cream with a topping).

Update: DessertItem class is an abstract class with an abstract method *calculate_cost.
        All subclasses can now calculate cost for specified dessert items.
        All cost or tax related objects are rounded to 2 decimal places.
        Print_order changed to print_receipt method for Order class has been changed to
        format and print using tabulate.
        date: Oct 3, 2025

Update: Added __str__ functions to all concrete subclasses to formate receipt.
        Added to_list() function to create 2d list from order and using __str__ functions from other classes
        to print a formated receipt of orders.
        Added Packaging object to all classes with their own values from packaging module.
        Updated __str__ methods in all classes to show type of packaging on receipt when printed.
        Oct 24, 2025

Update: Added __eq__, __ne__, __lt__, __gt__,__ge__, __le__ into DessertItem class to help sort order items.
        Added sort() method to sort order items by price before printing receipt (Called in dessertshop module).
        Nov 14, 2025


Author: Spencer Pahulu
Date: Nov 14, 2025
"""
from abc import ABC, abstractmethod
from tabulate import tabulate #type: ignore
from packaging import Packaging  # type: ignore
from payment import PayType, Payable

#
#DessertItem class as Abstract class for storing names of Dessert Items taken from subclasses
#
class DessertItem(Packaging):

    def __init__(self, name = ''):
        self.name = name
        self.tax_percent = 7.25
        self.packaging = None #type: ignore

    #
    # abstract method/ will be overwritten in subclasses to get correct cost for different desert items
    #
    @abstractmethod
    def calculate_cost(self):
        ...

    #Method to calculate tax and round it to 2 decimal points
    def calculate_tax(self):
        return round(((self.calculate_cost() * self.tax_percent) / 100), 2)

    def __eq__(self, other):
        if isinstance(other, DessertItem):
            return self.calculate_cost() == other.calculate_cost()
        return NotImplemented

    def __ne__(self, other):
        return not self.__eq__(other)

    def __lt__(self, other):
        if isinstance(other, DessertItem):
            return self.calculate_cost() < other.calculate_cost()
        return NotImplemented

    def __gt__(self, other):
        if isinstance(other, DessertItem):
            return self.calculate_cost() > other.calculate_cost()
        return NotImplemented

    def __le__(self, other):
        if isinstance(other, DessertItem):
            return self.calculate_cost() <= other.calculate_cost()
        return NotImplemented

    def __ge__(self, other):
        if isinstance(other, DessertItem):
            return self.calculate_cost() >= other.calculate_cost()
        return NotImplemented


#
#Candy subclass takes the name weight and price per pound to calculate cost and store name in parent class
#
class Candy(DessertItem):

    def __init__(self, name: str = '', candy_weight: float = 0.0, price_per_pound: float = 0.0):

        super().__init__(name) #type: ignore
        self.candy_weight = candy_weight
        self.price_per_pound = price_per_pound
        self.packaging = 'Bag'

    def calculate_cost(self):
        return round(self.candy_weight * self.price_per_pound, 2)

    def __str__(self):
        return (f'{self.name} ({self.packaging})\n -   {self.candy_weight}Ibs. @ ${self.price_per_pound}/Ib:,'
                f'${round(self.calculate_cost(),2)}, [Tax: ${round(self.calculate_tax(),2)}]')

#
#Cookie subclass takes the name cookie quantity and price per dozen to calculate cost
#
class Cookie(DessertItem):

    def __init__(self, name: str = '', cookie_quantity: int = 0,
                 price_per_dozen: float = 0.0):

        super().__init__(name) #type: ignore
        self.cookie_quantity = cookie_quantity
        self.price_per_dozen = price_per_dozen
        self.packaging = 'Box'

    def calculate_cost(self):
        return round(((self.cookie_quantity / 12) * self.price_per_dozen), 2)

    def __str__(self):
        return (f'{self.name} ({self.packaging})\n -   {self.cookie_quantity} cookies. @ ${self.price_per_dozen}/dozen:,'
                f' ${round(self.calculate_cost(),2)}, [Tax: ${round(self.calculate_tax(),2)}]')

#
#Ice Cream subclass takes the name scoop count and price per scoop to calculate cost
#
class IceCream(DessertItem):
    def __init__(self, name = '', scoop_count: int = 0, price_per_scoop: float = 0.0):

        super().__init__(name) #type: ignore
        self.scoop_count = scoop_count
        self.price_per_scoop = price_per_scoop
        self.packaging = 'Bowl'

    def calculate_cost(self):
        return round(self.scoop_count * self.price_per_scoop, 2)

    def __str__(self):
        return (f'{self.name} ({self.packaging})\n -   {self.scoop_count} scoops. @ ${self.price_per_scoop}/scoop:,'
                f'${round(self.calculate_cost(),2)}, [Tax: ${round(self.calculate_tax(),2)}]')

#
#Sundae subclass takes the name scoop count price per scoop along with topping name and topping price
#to calculate cost. Note: The parent class is IceCream
#
class Sundae(IceCream):
    def __init__(self, name = '', scoop_count: int = 0, price_per_scoop: float = 0.0,
                 topping_name: str = '', topping_price: float = 0.0):
        super().__init__(name, scoop_count, price_per_scoop) #type ignore
        self.topping_name = topping_name
        self.topping_price = topping_price
        self.packaging = 'Boat'

    #Note: Cost for sundae is the same as IceCream + topping price
    def calculate_cost(self):
        return round(self.scoop_count * self.price_per_scoop + self.topping_price, 2)

    def __str__(self):
        return (f'{self.name} ({self.packaging})\n -   {self.scoop_count} scoops. @ ${self.price_per_scoop}/scoop '
                f'\n-   {self.topping_name} topping @ ${self.topping_price}, ${round(self.calculate_cost(),2)},'
                f' [Tax: ${round(self.calculate_tax(),2)}]')

#
#Order class takes names from DessertItem to make a list to calculate subtotals tax and total cost
#
class Order(DessertItem):
    def __init__(self, pay_type: PayType = PayType.CASH):
        super().__init__()
        self.order = []  # type: ignore
        self.pay_type = pay_type

    def add(self, item: DessertItem):
        self.order.append(item)

    def __len__(self):
        return len(self.order)

    def calculate_cost(self):
        pass

    def order_cost(self):
        total_cost = 0
        for item in self.order:
            total_cost += item.calculate_cost()

        return round(total_cost, 2)

    def order_tax(self):
        tax = 0
        for item in self.order:
            tax += item.calculate_tax()

        return round(tax, 2)

    def get_pay_type(self) -> PayType:
        if not isinstance(self.pay_type, PayType):
            raise ValueError("Invalid payment type found.")
        return self.pay_type

    def set_pay_type(self, payment_method: PayType) -> None:
        if not isinstance(payment_method, PayType):
            raise ValueError(f"Invalid payment type: {payment_method}")
        self.pay_type = payment_method  # type: ignore


    def __str__(self):
        order_lines = []
        for item in self.order:
            order_lines.append(item.__str__())

        return '\n'.join(order_lines)

    def sort(self):
        self.order.sort()

    def to_list(self):
        order_str = str(self)
        lines = order_str.split('\n')
        result_list = []

        for line in lines:
            result_list.append([item.strip() for item in line.split(',')])

        result_list.append(['-------------------------------', '---------', '------------'])
        result_list.append([f'Total Number of Items in order:', f'{len(self.order)}'])
        result_list.append([f'Order Subtotal:', f'${round(self.order_cost(), 2)}',
                            f'[Tax: ${round(self.order_tax(), 2)}]'])
        result_list.append([f'Order Total:','', f'${round(self.order_cost() + self.order_tax(), 2)}'])
        result_list.append(['---------------------'])
        result_list.append([f'Paid with {self.get_pay_type().value}'])
        result_list.append(['-------------------------------', '---------', '------------'])

        return result_list



    def print_receipt(self):

        #
        # Create empty list to store receipt information to use for tabulate formatting
        #
        receipt_data = []

        #loop to create a list for all items within an order which will be used in printing the formatted receipt
        for item in self.order:
            receipt_data.append([item.name, f'${item.calculate_cost():.2f}', f'${item.calculate_tax():.2f}'])

        receipt_data.append(['-----------------', '---------', '-------']) #acts as a break
        receipt_data.append([' Order Subtotals', f'${self.order_cost():.2f}',
                             f'${self.order_tax():.2f}'])
        receipt_data.append(['Order Total', f'${self.order_cost() + self.order_tax():.2f}', ''])
        receipt_data.append(['Total Items in the order', str(len(self.order))])
        receipt_data.append([f'Paid with {self.get_pay_type().value}'])

        print(tabulate(receipt_data, headers=['Name', 'Cost', 'Tax'], tablefmt='fsql'))





