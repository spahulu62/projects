"""
Test code for functions and classes for the Dessert Shop(dessert.py)
The current test for each of the classes are for the default values, provided values, updated values
What is written so far as of Sept 27, 2025 should be 100% of test cases pass and each value provided and
updated to should also be the expected outcome.

Funny note: Writing this test code actually showed me I forgot to insert the proper default name value for the IceCream
and Sundae classes

Update: Use Candy Class to test abstract and non-abstract methods in DessertItem superclass
        New test to check if abstract class cant be instantiated
        New test to check if calculated_cost method is overwritten correctly
        New test to check if calculated_tax method is computing correctly
        Oct 5,2025

Update: Added test to check if correct value for packaging
        Oct 24 ,2025

Update: Added test to check all operators that was added to DessertItem Class

Author: Spencer Pahulu
Date: Nov 14, 2025
"""
import pytest

from dessert import DessertItem, Candy




class TestDessertItem:

    #test if abstract method is overwritten and runs correctly
    def test_abstract(self):
        instance = Candy('Candy Corn',1.5,0.25)
        assert instance.calculate_cost() == 0.38

    #test of class is abstract
    def test_abstract_class_cannot_be_instantiated(self):
        with pytest.raises(TypeError):
            DessertItem()

    #test default attributes in DessertItem are correct
    def test_default_attributes(self):
        instance = Candy()
        assert instance.name == ''
        assert instance.tax_percent == 7.25

    #test if providing an attribute will produce correct value
    def test_provided_attributes(self):
        instance = Candy('Gummy Bear')
        assert instance.name == 'Gummy Bear'
        #Note: tax_percent is an attribute in DessertItem class but has to be provided the same as
        #      updating attributes so will be tested in next test


    #test if updating attributes are working correctly
    def test_update_attributes(self):
        instance = Candy()
        assert instance.name == ''
        instance.name = 'Candy Corn'
        assert instance.name == 'Candy Corn'
        instance.tax_percent = 100
        assert instance.tax_percent == 100

    #Set values to Concrete class to test if the calculate_tax method is working correctly
    def test_tax_percent(self):
        instance = Candy('Candy Corn',1.5,.25)
        assert instance.tax_percent == 7.25 #default tax percentage given in DessertItem Class
        assert instance.calculate_tax() == 0.03 # (1.5 * .25 * 7.25) / 100 = 0.03

    def test_packaging(self):
        instance = Candy('Candy Corn',1.5,0.25)
        assert instance.packaging == 'Bag'

    def test_operators(self):
        instance_1 = Candy('Candy Corn',1.5,0.25)
        instance_2 = Candy('Gummy Bear',.35,0.25)
        instance_3 = Candy('Candy Corn',1.5,0.25)

        assert (instance_1 == instance_2) is False
        assert (instance_1 == instance_3) is True

        assert (instance_1 != instance_2) is True
        assert (instance_1 != instance_3) is False

        assert (instance_1 > instance_2) is True
        assert (instance_1 > instance_3) is False

        assert (instance_1 >= instance_2) is True
        assert (instance_1 >= instance_3) is True

        assert (instance_1 < instance_2) is False
        assert (instance_1 < instance_3) is False

        assert (instance_1 <= instance_2) is False
        assert (instance_1 <= instance_3) is True

