"""
Test code for functions and classes for the Dessert Shop(dessert.py)
The current test for each of the classes are for the default values, provided values, updated values
What is written so far as of Sept 27, 2025 should be 100% of test cases pass and each value provided and
updated to should also be the expected outcome.

Funny note: Writing this test code actually showed me I forgot to insert the proper default name value for the IceCream
and Sundae classes

Update: New test if new abstract method calculated_cost is overwritten and working correctly
        New test for calculate_tax method is computing correctly
        Oct 5,2025

Update: Added test to check if correct value for packaging
        Oct 24 ,2025

Author: Spencer Pahulu
Date: October 24, 2025
"""
import pytest
from dessert import IceCream

#
#Test Class to test Ice Cream Class
#
class TestIceCream:
    #test if default values are correct
    def test_default_attributes(self):
        icecream = IceCream()
        assert icecream.name == ''
        assert icecream.price_per_scoop == 0.0
        assert icecream.scoop_count == 0

    #test if provided values will update and contain correct values
    def test_provided_attributes(self):
        icecream = IceCream('Bubble Gum', 1, 1.5)
        assert icecream.name == 'Bubble Gum'
        assert icecream.price_per_scoop == 1.5
        assert icecream.scoop_count == 1

    #test if updating provided values update and contain correct values
    def test_update_attributes(self):
        icecream = IceCream('Bubble Gum', 1, 1.5)
        icecream.name = 'Strawberry'
        icecream.price_per_scoop = 2.5
        icecream.scoop_count = 2
        assert icecream.name == 'Strawberry'
        assert icecream.price_per_scoop == 2.5
        assert icecream.scoop_count == 2

    # test if calculate_cost method is computing correctly
    def test_calculate_cost(self):
        icecream = IceCream("Pistachio", 2, .79)
        assert icecream.calculate_cost() == 1.58

    # test if calculate_tax from super class is computing correctly
    def test_calculate_tax(self):
        icecream = IceCream("Pistachio", 2, .79)
        assert icecream.calculate_tax() == 0.11

    def test_packaging(self):
        icecream = IceCream("Pistachio", 2, .79)
        assert icecream.packaging == 'Bowl'