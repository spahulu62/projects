"""
DessertShop application driver. imports for dessert.py classes to print order items
and number of items in customer order

Update: We now use tabulate to format and print our receipt.

        date: Oct 3, 2025

Update: Create DessertShop Class that takes user inputs to fill in the customer order.
        Added loop in main function that takes user inputs to choose which item they want.
        date: Oct 10, 2025

Update: Use order.to_list() function in tabulate format to print receipt.
        date: Oct 24, 2025

Update: Call sort() from Order Class to sort items in order by price before printing receipt.

Author: Spencer Pahulu
Date: Nov 14, 2025
"""

from dessert import Candy, Cookie, IceCream, Sundae, Order
from tabulate import tabulate  # type: ignore

from payment import PayType, Payable

def main():

    class DessertShop:
        @staticmethod
        def user_prompt_candy():

            while True:
                try:
                    name = str(input('Enter the name of your candy: '))

                    if name == '':
                        raise NameError('Name of candy cannot be empty. Please try again.')

                    else:
                        break


                except NameError:
                    print('Name of candy cannot be empty. Please try again.')

            while True:
                try:
                    candy_weight = float(input('Enter the candy weight of your candy: '))

                    if candy_weight <= 0:
                        raise ValueError('Candy weight must be greater than zero. Please try again.')

                    else:
                        break

                except ValueError as e:
                    print(e)

            while True:
                try:
                    price_per_pound = float(input('Enter the price per pound of your candy: '))

                    if price_per_pound <= 0:
                        raise ValueError('Price per pound must be greater than zero. Please try again.')

                    else:
                        break

                except ValueError as e:
                    print(e)

            return Candy(name, candy_weight, price_per_pound)


        @staticmethod
        def user_prompt_cookie() -> Cookie:

            while True:
                try:
                    name = str(input('Enter the name of your cookie: '))

                    if name == '':
                        raise NameError('Name of cookie cannot be empty. Please try again.')

                    else:
                        break

                except NameError as e:
                    print(e)

            while True:
                try:
                    cookie_quantity = float(input('Enter the amount of cookies you want: '))

                    if cookie_quantity <= 0:
                        raise ValueError('Cookie amount must be greater than zero. Please try again.')

                    else:
                        break

                except ValueError as e:
                    print(e)

            while True:
                try:
                    price_per_dozen = float(input('Enter the price per dozen of your cookie: '))

                    if price_per_dozen <= 0:
                        raise ValueError('Price per dozen must be greater than zero. Please try again.')

                    else:
                        break

                except ValueError as e:
                    print(e)


            return Cookie(name, cookie_quantity, price_per_dozen)  # type: ignore

        @staticmethod
        def user_prompt_icecream() -> IceCream:

            while True:
                try:
                    name = str(input('Enter the name of your icecream: '))

                    if name == '':
                        raise NameError('Name of Ice Cream cannot be empty. Please try again.')

                    else:
                        break

                except NameError as e:
                    print(e)

            while True:
                try:
                    scoop_count = int(input('Enter the number of scoops on your icecream: '))

                    if scoop_count <= 0:
                        raise ValueError('Scoop count must be greater than zero. Please try again.')

                    else:
                        break

                except ValueError as e:
                    print(e)

            while True:
                try:
                    price_per_scoop = float(input('Enter the price per scoop of your icecream: '))

                    if price_per_scoop <= 0:
                        raise ValueError('Price per scoop must be greater than zero. Please try again.')

                    else:
                        break

                except ValueError as e:
                    print(e)

            return IceCream(name, scoop_count, price_per_scoop)

        @staticmethod
        def user_prompt_sundae() -> Sundae:

            while True:
                try:
                    name = str(input('Enter the name of your icecream: '))

                    if name == '':
                        raise NameError('Name of Ice Cream cannot be empty. Please try again.')

                    else:
                        break

                except NameError as e:
                    print(e)

            while True:
                try:
                    scoop_count = int(input('Enter the number of scoops on your icecream: '))

                    if scoop_count <= 0:
                        raise ValueError('Scoop count must be greater than zero. Please try again.')

                    else:
                        break

                except ValueError as e:
                    print(e)

            while True:
                try:
                    price_per_scoop = float(input('Enter the price per scoop of your icecream: '))

                    if price_per_scoop <= 0:
                        raise ValueError('Price per scoop must be greater than zero. Please try again.')

                    else:
                        break

                except ValueError as e:
                    print(e)

            while True:
                try:
                    topping_name = str(input('Enter the name of your topping: '))

                    if topping_name == '':
                        raise NameError('Name of topping cannot be empty. Please try again.')

                    else:
                        break

                except NameError as e:
                    print(e)

            while True:
                try:
                    topping_price = float(input('Enter the price of your topping: '))

                    if topping_price <= 0:
                        raise ValueError('Topping weight must be greater than zero. Please try again.')

                    else:
                        break

                except ValueError as e:
                    print(e)

            return Sundae(name, scoop_count, price_per_scoop, topping_name, topping_price)

    '''----------------------------------------------------------------------------------------------------------------
    #Customer Order:
    
    order.add(Candy("Candy Corn", 1.5, .25))
    order.add(Candy("Gummy Bears", .25, .35))
    order.add(Cookie("Chocolate Chip", 6, 3.99))
    order.add(IceCream("Pistachio", 2, .79))
    order.add(Sundae("Vanilla", 3, .69,
                              "Hot Fudge", 1.29))
    order.add(Cookie("Oatmeal Raisin", 2, 3.45))
    -----------------------------------------------------------------------------------------------------------------'''
    #
    #Create objects to store all relevant information of dessert items in Order class
    #
    order = Order()
    shop = DessertShop()

    done: bool = False #type: ignore
    # build the prompt string once
    prompt = '\n'.join([ '\n',
            '1: Candy',
            '2: Cookie',
            '3: Ice Cream',
            '4: Sundae',
            '\nWhat would you like to add to the order? (1-4, Enter for done): '
      ])

    while not done:
      choice = input(prompt)
      match choice:
        case '':
          done = True
        case '1':
          item = shop.user_prompt_candy()
          order.add(item)
          print(f'{item.name} has been added to your order.')
        case '2':
          item = shop.user_prompt_cookie()
          order.add(item)
          print(f'{item.name} has been added to your order.')
        case '3':
          item = shop.user_prompt_icecream()
          order.add(item)
          print(f'{item.name} has been added to your order.')
        case '4':
          item = shop.user_prompt_sundae()
          order.add(item)
          print(f'{item.name} has been added to your order.')
        case _:
          print('Invalid response:  Please enter a choice from the menu (1-4) or Enter')

    pay_prompt = '\n'.join([ '\n',
                             '1. Cash',
                             '2. Card',
                             '3. Phone',
                             'Enter payment method: '
                             ])
    while True:
        choice = input(pay_prompt)
        match choice:
            case '':
                break
            case '1':
                pay_type = PayType.CASH
                order.set_pay_type(pay_type)
                break
            case '2':
                pay_type = PayType.CARD
                order.set_pay_type(pay_type)
                break
            case '3':
                pay_type = PayType.PHONE
                order.set_pay_type(pay_type)
                break
            case _:
                print('Invalid response:  Please choose payment method (1-3) or Enter')

    order.sort()
    print()
    print(tabulate(order.to_list(), headers = ['Name','Cost', 'Tax'], tablefmt="fsql")) #print receipt

if __name__ == '__main__':
    main()